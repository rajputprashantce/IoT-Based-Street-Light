<meta http-equiv="refresh" content="0;url=home.php">
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "ASMS6";

$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
    echo ("Database Cannot Connect Due to".mysqli_connect_error());
}
else{
    echo ("Database Connected Successfully");
    
    $selcity = $_POST['selcity'];
    $editarea = $_POST['editarea'];
    $streetlightcount = $_POST['streetlightcount'];

    $sqlinsert = "INSERT INTO `home` (`City`, `Area`, `lights`) VALUES ('$selcity', '$editarea', '$streetlightcount')";
    $result = mysqli_query($conn , $sqlinsert);

    if ($result) {
        echo '<div class="alert alert-success">
        <strong>Success!</strong> Record Inserted Successfully..!
      </div>';

    }
    else {
        echo '<div class="alert alert-danger">
        <strong>Failed!</strong> Record Was Not Inserted..!
      </div>';
    }

}

?>