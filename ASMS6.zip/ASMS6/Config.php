<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "ASMS6";

$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
    echo ("Database Cannot Connect Due to".mysqli_connect_error());
}
else{
    echo ("Database Connected Successfully");
}

?>