<?php
include('headerautorefresh.php');
include('footer.php');
?>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "ASMS6";

$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
    echo ("Database Cannot Connect Due to".mysqli_connect_error());
}
else{
 //   echo ("Database Connected Successfully");
}
?>
<!-- <h3>
    Welcome <?php //echo $_SESSION['user_id']; ?>
</h3> -->

<table class="table">
    <!-- <caption>List of users</caption> -->
    <thead>
        <tr>
            <th scope="col">Sr No.</th>
            <th scope="col">City</th>
            <th scope="col">Area</th>
            <th scope="col">No Of Lighs</th>
            <th scope="col">Status</th>
            <th scope="col">Controls</th>
            <!-- <th scope="col">Troubleshoot</th> -->
        </tr>
    </thead>
<?php


$sql = "SELECT * FROM `home`";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
//echo $num."<br>";

if ($num > 0) {
    for ($i = 0; $i<$num ; $i++){
        $row = mysqli_fetch_assoc($result);
    //    echo var_dump($row)."<br>";

?>

    <tbody>
        <tr>
            <th scope="row"><?php echo $row['sr_no'];?></th>
            <td><?php echo $row['City'];?></td>
            <td><?php echo $row['Area'];?></td>
            <td><?php echo $row['lights'];?></td>

            <?php 
                $sql2 = "SELECT * FROM logs ORDER BY id DESC LIMIT 1";
                $result2 =  mysqli_query($conn, $sql2);
                $print_data = mysqli_fetch_row($result2);
                // echo $print_data[2];
                // echo print_r($print_data);
                // echo $row['sensor2'];
            ?>
<div class="auto" id="auto">

            
            <?php if ($print_data[2] == 0) { ?>
                <td style="color: green;">ON</td><?php
                // echo "OFF";
            }
            else if ($print_data[2]==1) {?>
                <td style="color: red;">OFF</td><?php
                // echo "ON";
            }
            else {  ?>
                <td style ="color:yellow;"> ⚠ Not Connected To Server </td> <?php
            }
            ?>
            <!-- ⚠ This Symbol Is Use For Some Of The Light Might Have An Issue -->
            <td>
                <!-- <div class="btn-group">
                    <button type="button" class="btn btn-primary">ON</button>
                </div>
                <div class="btn-group">
                    <button type="button" class="btn btn-primary">OFF</button>
                </div>
                <div class="btn-group" id="delete">
                    <button type="button" class="btn btn-danger">DELETE</button>
                </div> -->
                <div class="btn-group" id="open">
                    <button type="button" class="btn btn-info"><a href="lights.php"> OPEN</a></button>
                </div>
            </td>
            <!-- <td><button type="button" class="btn btn-primary">Troubleshoot</button></td> -->
        </tr>
    </tbody>
    <?php 
        }
    } 
    ?>
    <tr>
        <td style="border-bottom:1px solid white;">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Add New
            </button>

            <!-- MODAL -->

            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add New</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <!-- Modal Body -->

                        <div class="modal-body">
                            <form action="home_submit.php" method="post">
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Select City</label>
                                    <select class="form-control" name="selcity" required>
                                        <option value="Patan">Patan</option>
                                        <option value="Mehsana">Mehsana</option>
                                        <option value="Unjha">Unjha</option>
                                        <option value="Kathpur">Kathput</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Area</label>
                                    <input class="form-control" type="text" name="editarea" placeholder="Area" required>
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect2">No Of Lights</label>
                                    <input class="form-control" type="number" name="streetlightcount"
                                        placeholder="No Of Lights" required>
                                </div><br>
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Insert</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </td>
    </tr>
    </tbody>
</table>