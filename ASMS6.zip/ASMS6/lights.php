<?php include ('headerautorefresh.php')?>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "ASMS6";

$conn = mysqli_connect($servername,$username,$password,$database);

if (!$conn) {
    echo ("Database Cannot Connect Due to".mysqli_connect_error());
}
else{
 //   echo ("Database Connected Successfully");
}
$sql = "SELECT * FROM `home`";
$result = mysqli_query($conn, $sql);

$num = mysqli_num_rows($result);
//echo $num."<br>";

if ($num > 0) {
    for ($i = 0; $i<$num ; $i++){
        $row = mysqli_fetch_assoc($result);
   //     echo var_dump($row)."<br>";
?>
<h3>
    <?php echo $row['Area'];?>,
    <?php echo $row['City'];?>
</h3>
<?php 
    }
} 
?>

<table class="table">
    <!-- <caption>List of users</caption> -->
    <thead>
        <tr>
            <th scope="col">Sr No.</th>
            <th scope="col">LDR Status</th>
            <th scope="col">Light Status</th>
            <th scope="col">Light ID</th>
            <th scope="col">Type</th>
            <th scope="col">Volt</th>
            <!-- <th scope="col">Controls</th> -->
            <!-- <th scope="col">Troubleshoot</th> -->
        </tr>
    </thead>
    <tbody>

    <?php 

    $sql2 = "SELECT * FROM logs ORDER BY id DESC LIMIT 1";
    $result2 =  mysqli_query($conn, $sql2);
    $print_data = mysqli_fetch_row($result2);
    // echo $print_data[2];
    // echo print_r($print_data);
    // echo $row['sensor2'];
        
?>
        <tr>
            <th scope="row">1</th>

            <?php if ($print_data[1] < 500) { ?>
            <td id="div_refresh" style="color: red;">LOW</td><?php
                // echo "OFF";
            }
            else if ($print_data[1] > 500) {?>
            <td id="div_refresh" style="color: green;">HIGH</td><?php
                // echo "ON";
            }
            ?>

            <?php if ($print_data[2] == 0) { ?>
            <td id="div_refresh" style="color: green;">ON</td><?php
                // echo "OFF";
            }
            else if ($print_data[2]==1) {?>
            <td id="div_refresh" style="color: red;">OFF</td><?php
                // echo "ON";
            }
            ?>
            
            <!-- <td style="color: green;"><?php //echo $print_data[2];?></td> -->

            <?php
            
            $sql = "SELECT * FROM `lights`";
            $result = mysqli_query($conn, $sql);

            $num = mysqli_num_rows($result);
            //echo $num."<br>";

            if ($num > 0) {
                for ($i = 0; $i<$num ; $i++){
                    $row = mysqli_fetch_assoc($result);
            ?>
            <td><?php echo $row['light_id']; ?></td>
            <td><?php echo $row['type']; ?></td>
            <td><?php echo $row['volt']; ?></td>

            <?php
                }
            }
            ?>
            <!-- <td>
                <a href=""><button type="button" class="btn btn-outline-success" href=\"/ledon\"\">ON</button></a>
                <button type="button" class="btn btn-outline-danger" href="192.168.0.104/ledoff">OFF</button>
                <button type="button" class="btn btn-outline-primary">Automated</button>
            </td> -->
            <!--⚠ This Symbol Is Use For Some Of The Light Might Have An Issue-->
            <!-- <td>
               <div class="btn-group">
                    <button type="button" class="btn btn-primary">ON</button>
                </div>
                <div class="btn-group">
                    <button type="button" class="btn btn-primary">OFF</button>
                </div>
                <div class="btn-group" id="delete">
                    <button type="button" class="btn btn-danger">DELETE</button>
                </div>
                 <div class="btn-group" id="open">
                    <button type="button" class="btn btn-info"><a href="lights.php"> OPEN</a></button>
                </div>
            </td>
          <td><button type="button" class="btn btn-primary">Troubleshoot</button></td>  -->
        </tr>

        <td style="border-bottom:1px solid white;">
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Add New
            </button>
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add New</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>

                        <!-- Modal Body -->

                        <div class="modal-body">
                            <form>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">light ID</label>
                                    <input class="form-control" type="number" placeholder="Default input">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect1">Type</label>
                                    <input class="form-control" type="text" placeholder="Default input">
                                </div>
                                <div class="form-group">
                                    <label for="exampleFormControlSelect2">Volt</label>
                                    <input class="form-control" type="number" placeholder="Default input">
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Insert</button>
                        </div>
                    </div>
                </div>
            </div>
    </tbody>
</table>
<?php include ('footer.php')?>