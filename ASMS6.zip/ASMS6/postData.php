<?php

    //Creates new record as per request
    //Connect to database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ASMS6";


    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }


    //Get current date and time
    date_default_timezone_set('Asia/Kolkata');
    $d = date("Y-m-d");
    //echo " Date:".$d."<BR>";
    $t = date("H:i:s");


    if(!empty($_POST['sensor1']) || !empty($_POST['sensor2']))
    {
        $sensorData1 = $_POST['sensor1'];
        $sensorData2 = $_POST['sensor2'];

    
        $sql2 = "SELECT * FROM logs ORDER BY id DESC LIMIT 1";
        $result2 =  mysqli_query($conn, $sql2);
        $print_data = mysqli_fetch_row($result2);
        // echo var_dump($print_data);
        // echo $row['sensor2'];
        if ($sensorData2 != $print_data[2]) {

            $sql = "INSERT INTO logs (sensor1, sensor2, Date, Time) VALUES ('".$sensorData1."', '".$sensorData2."', '".$d."', '".$t."')";

            if ($conn->query($sql) === TRUE) {
                echo "OK";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }            
        }
        
        // $sql = "INSERT INTO logs (sensor1, sensor2, Date, Time) VALUES ('".$sensorData1."', '".$sensorData2."', '".$d."', '".$t."')";
        
    }
    $conn->close();
?>