<?php

//Creates new record as per request
    //Connect to database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "ASMS6";


    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }


    //Get current date and time
    date_default_timezone_set('Asia/Kolkata');
    $d = date("Y-m-d");
    //echo " Date:".$d."<BR>";
    $t = date("H:i:s");


    if(!empty($_POST['sensor1']) || !empty($_POST['sensor2']))
    {
        $sensorData1 = $_POST['sensor1'];
        $sensorData2 = $_POST['sensor2'];


        $sql = "INSERT INTO logs (sensor1, sensor2, Date, Time) VALUES ('".$sensorData1."', '".$sensorData2."', '".$d."', '".$t."')";


        if ($conn->query($sql) === TRUE) {
            echo "OK";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
?>