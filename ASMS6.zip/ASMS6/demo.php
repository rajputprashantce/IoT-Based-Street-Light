    <button id="reload">
        Reload
    </button>

    <div id="Content">
        <?php echo rand(0,100);?>
    </div>
<!-- -----------------------------------------------------Script---------------------------------------------------------------- -->
<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-1.11.3.min.js' ?>"></script>
<script type="text/javascript">
$("#reloader").click(function () {
    $("#content").load("#content");
})


</script>
